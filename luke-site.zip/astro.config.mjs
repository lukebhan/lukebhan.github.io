import { defineConfig } from 'astro/config';
export default defineConfig({
  site: 'https://lukebhan.com',
});
