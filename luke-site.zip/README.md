# lukebhan.com

Personal academic site built with [Astro](https://astro.build). Mobile-first, ships
almost no JavaScript, installable as a PWA.

## Develop
```bash
npm install
npm run dev      # http://localhost:4321
```

## Build
```bash
npm run build    # static output in ./dist
npm run preview  # preview the build
```

## Editing content
All content lives in `src/data/` as JSON — no need to touch markup:
- `site.json` — name, nav, hero, proof chips, About facts/links, the three research frontiers
- `publications.json` — selected + recent papers (authors, venue, links). Set `"me": true` to bold your name, `"star": true` for equal-contribution.
- `talks.json`, `teaching.json`, `experience.json`, `news.json`

Design tokens (colors, fonts) are at the top of `src/styles/global.css`.

## Before going live
1. Add `public/portrait.jpg` (your photo) and `public/cv.pdf` / `public/research_statement.pdf`.
2. Optionally self-host the hero figure: drop it in `public/` and point `site.json > hero.image` at `/hero.png`.
3. Add 192px and 512px PNG icons to `public/` and list them in `manifest.webmanifest` for full Android install support.

## Deploy
Static output — works on GitHub Pages, Netlify, Vercel, or Cloudflare Pages. For GitHub Pages, set `base`/`site` in `astro.config.mjs` and publish `dist/`.
